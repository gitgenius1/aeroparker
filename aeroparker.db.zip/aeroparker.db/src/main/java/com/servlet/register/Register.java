package com.servlet.register;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/register")
public class Register extends HttpServlet {
	
	//create the query 
	private static final String INSERT_QUERY = "INSERT INTO AEROPARKER(EMAILADDRESS,TITLE,FIRSTNAME,SECONDNAME,ADDRESSLINE1,ADDRESSLINE2,CITY,POSTCODE,TELEPHONENUMBER) VALUES(?,?,?,?,?,?,?,?,?)"; 
	

	@Override
	public void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
	
		//get printwriter
		PrintWriter pw = res.getWriter();
		//set content type (text)
		res.setContentType("text/html");
		// read the form values 
		
		String emailAddress = req.getParameter("emailaddress");
		String title = req.getParameter("title");
		String firstName = req.getParameter("firstname");
		String secondName = req.getParameter("secondname");
		String addressLine1 = req.getParameter("addressline1");
		String addressLine2 = req.getParameter("addressline2");
		String city = req.getParameter("city");
		String postCode = req.getParameter("postcode");
		String telephoneNumber = req.getParameter("telephonenumber");

		//load JDBC driver
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		//create the connection
		
		try(Connection conn = DriverManager.getConnection("jdbc:mysql:localhost:3306/aeroparker")) {
			PreparedStatement ps = conn.prepareStatement(INSERT_QUERY);
			
			//set values
			ps.setString(1, emailAddress);
			ps.setString(2, title);
			ps.setString(3, firstName);
			ps.setString(4, secondName);
			ps.setString(5, addressLine1);
			ps.setString(6, addressLine2);
			ps.setString(7, city);
			ps.setString(8, postCode);
			ps.setString(9, telephoneNumber);
			
			//excute query
			int count = ps.executeUpdate();
			
			if(count==0) {
			
				pw.println("signup Unsuccesfull");
			}
			else {
				pw.println("Your all Signed up");
			}
			
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			pw.println(e.getMessage());
		} catch (Exception e) {
			e.printStackTrace();
			pw.println(e.getMessage());
		}
			
		//close the stream
		pw.close();
	}
	
	@Override
	public void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		doGet(req, resp);
	}

}
