package com.aeroparker.aeroparker.service;

import com.aeroparker.aeroparker.entities.Sites;

public interface SiteService {
	public void addSite(Sites site) throws Exception;
}
