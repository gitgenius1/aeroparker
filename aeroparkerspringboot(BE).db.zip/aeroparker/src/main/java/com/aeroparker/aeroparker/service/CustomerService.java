package com.aeroparker.aeroparker.service;

import com.aeroparker.aeroparker.entities.Customers;

public interface CustomerService {
	
public void addCustomer(Customers customer, String sitename) throws Exception ;
}
