package com.aeroparker.aeroparker.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.aeroparker.aeroparker.entities.Customers;
import com.aeroparker.aeroparker.service.CustomerService;

@RestController
public class CustomerController {
	@Autowired
	private CustomerService customerService;

	@PostMapping(value = "/customer/{siteName}")
	public ResponseEntity<String> addCustomer(@RequestBody Customers customer, @PathVariable("siteName") String siteName) {
		try {
			customerService.addCustomer(customer, siteName);
		} catch (Exception e) {
			e.printStackTrace();
			return new ResponseEntity<String>(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity<String>("Customer added susscessfully", HttpStatus.CREATED);
	}
	
}
