package com.aeroparker.aeroparker;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AeroparkerApplication {

	public static void main(String[] args) {
		SpringApplication.run(AeroparkerApplication.class, args);
	}

}
