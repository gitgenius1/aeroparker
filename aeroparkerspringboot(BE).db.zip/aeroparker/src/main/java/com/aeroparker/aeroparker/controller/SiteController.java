package com.aeroparker.aeroparker.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.aeroparker.aeroparker.entities.Sites;
import com.aeroparker.aeroparker.service.SiteService;

@RestController
public class SiteController {
	@Autowired
	private SiteService siteService;

	@PostMapping(value="/site")
	public ResponseEntity<String> addSites(@RequestBody Sites sites) {
		try {
			siteService.addSite(sites);
		} catch (Exception e) {
			return new ResponseEntity<>(e.getMessage(),HttpStatus.NOT_ACCEPTABLE);
		}
		return new ResponseEntity<String>("Site added successfullt",HttpStatus.CREATED);
	}

	
	
}
