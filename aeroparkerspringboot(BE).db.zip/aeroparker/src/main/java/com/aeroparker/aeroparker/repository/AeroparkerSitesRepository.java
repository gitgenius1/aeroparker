package com.aeroparker.aeroparker.repository;

import java.util.Optional;

import org.springframework.data.repository.CrudRepository;

import com.aeroparker.aeroparker.entities.Customers;
import com.aeroparker.aeroparker.entities.Sites;

public interface AeroparkerSitesRepository extends CrudRepository<Sites, Integer> {

	
	public Optional<Sites> findByName(String name);
	
}
