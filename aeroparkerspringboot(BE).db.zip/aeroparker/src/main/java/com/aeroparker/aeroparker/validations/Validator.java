package com.aeroparker.aeroparker.validations;

public class Validator {

	public static boolean verifyEmail(String email) {
		String regex = "[A-z0-9\\.]+\\@[A-z].[com|in|org|uk]";
		return email.matches(regex);
	}

	public static boolean verifyName(String firstName, String secondName) {
		String regex = "[A-z\\ ]+";
		return firstName.matches(regex) && secondName.matches(regex);
	}
}