package com.aeroparker.aeroparker.service;

import java.time.LocalDateTime;
import java.util.Optional;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.aeroparker.aeroparker.entities.Customers;
import com.aeroparker.aeroparker.entities.Sites;
import com.aeroparker.aeroparker.repository.AeroparkerCustomerRepository;
import com.aeroparker.aeroparker.validations.Validator;

@Service
public class CustomerServiceImpl implements CustomerService {
	
	@Autowired AeroparkerCustomerRepository aeroparkercustomerrepository;
	
	@Autowired SiteService siteService;
	
	public void addCustomer(Customers customer, String siteName) throws Exception {
		boolean flag = true; 
		
		flag = Validator.verifyEmail(customer.getEmailAddress());
		flag = Validator.verifyName(customer.getFirstName(), customer.getSecondName());	
		
		if(flag == false) {
			throw new Exception("Email or Name incorrect");
			
		} 
		customer.setRegistered(LocalDateTime.now());
		Optional<Customers> opt = aeroparkercustomerrepository.findByEmailAddress(customer.getEmailAddress());
		if(!opt.isPresent()) {
			aeroparkercustomerrepository.save(customer);
			Sites site = new Sites();
			site.setName(siteName);
			siteService.addSite(site);
		}
		else {
			Customers custFromDB = opt.get();
			Set<Sites> sites =  custFromDB.getSites();
			Sites site = new Sites();
			site.setName(siteName);
			sites.add(site);
			siteService.addSite(site);
			aeroparkercustomerrepository.save(customer);	
		}
	}
	
	

	public void sendVerificationEmail(Customers customer) {
		String subject = "Please verify your email";
		String senderName = "Aeroparker";
		String mailContent = "<p> Dear " + customer.getFirstName() + customer.getSecondName() + "</p>";
		mailContent += "<p> Please click the link below to verify your email</p>";
		
		mailContent += "<p>Thank you<br>The Aeroparker team</p>";
	}
	
}
