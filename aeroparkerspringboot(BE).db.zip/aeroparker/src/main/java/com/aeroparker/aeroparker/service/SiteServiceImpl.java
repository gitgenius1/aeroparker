package com.aeroparker.aeroparker.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.aeroparker.aeroparker.entities.Sites;
import com.aeroparker.aeroparker.repository.AeroparkerSitesRepository;

@Service
public class SiteServiceImpl implements SiteService {

	
	@Autowired
	AeroparkerSitesRepository aeroparkerSitesRepository;
	
	
	public void addSite(Sites site) throws Exception{
		Optional<Sites> opt = aeroparkerSitesRepository.findByName(site.getName());
		if(opt.isPresent()) {
			throw new Exception("Site already exists");
		} else {
		aeroparkerSitesRepository.save(site);
		
		}
	}
}
