package com.aeroparker.aeroparker.repository;

import java.util.Optional;

import org.springframework.data.repository.CrudRepository;

import com.aeroparker.aeroparker.entities.Customers;

public interface AeroparkerCustomerRepository extends CrudRepository<Customers, Integer> {
	
	public Optional<Customers> findByEmailAddress(String EmailAddress);

	
	
	
}
